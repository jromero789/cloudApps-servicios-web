@org.springframework.modulith.ApplicationModule(
  allowedDependencies = {"infrastructure::models", "infrastructure::repositories", "domain::port"}
)
package com.codeurjc.arq1.infrastructure;