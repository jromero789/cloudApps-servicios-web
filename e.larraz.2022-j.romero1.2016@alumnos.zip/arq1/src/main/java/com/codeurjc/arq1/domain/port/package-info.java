@org.springframework.modulith.NamedInterface("port")
package com.codeurjc.arq1.domain.port;