@org.springframework.modulith.NamedInterface("repositories")
package com.codeurjc.arq1.infrastructure.repositories;