@org.springframework.modulith.ApplicationModule(
  allowedDependencies = {"domain::port"}
  
)
package com.codeurjc.arq1.domain;