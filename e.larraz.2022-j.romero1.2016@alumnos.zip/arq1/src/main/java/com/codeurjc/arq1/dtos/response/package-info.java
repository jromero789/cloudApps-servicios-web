@org.springframework.modulith.NamedInterface("response")
package com.codeurjc.arq1.dtos.response;