@org.springframework.modulith.NamedInterface("request")
package com.codeurjc.arq1.dtos.request;