@org.springframework.modulith.ApplicationModule(
  allowedDependencies = {"dtos::response", "dtos::request"}
  
)
package com.codeurjc.arq1.services;