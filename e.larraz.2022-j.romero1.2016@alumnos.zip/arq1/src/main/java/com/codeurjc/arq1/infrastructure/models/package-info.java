@org.springframework.modulith.NamedInterface("models")
package com.codeurjc.arq1.infrastructure.models;