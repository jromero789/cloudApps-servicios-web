@org.springframework.modulith.ApplicationModule(
  allowedDependencies = {"dtos::request", "dtos::response", "services"}
  
)
package com.codeurjc.arq1.controllers;