# EoloPlanner
- Master: CloudApps URJC
- Asignatura: Patrones y arquitecturas de servicios web
- Práctica 1 – Arquitectura hexagonal

- Alumnos: Eduardo Larraz, Juan Romero González
- Email: e.larraz.2022@alumnos.urjc.es, j.romero1.2016@alumnos.urjc.es
- Fecha: 12/12/2022

## Github práctica:
- https://github.com/jromero789/cloudApps-servicios-web